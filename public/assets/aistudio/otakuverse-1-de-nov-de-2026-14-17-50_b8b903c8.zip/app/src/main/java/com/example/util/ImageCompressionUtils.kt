package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object ImageCompressionUtils {

    private const val TAG = "ImageCompression"

    suspend fun processAndSaveAvatar(context: Context, sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val original = loadBitmap(context, sourceUri)
                ?: return@withContext Result.failure(IllegalStateException("Não foi possível carregar imagem do avatar."))

            // Crop 1:1
            val minSide = minOf(original.width, original.height)
            val cropX = (original.width - minSide) / 2
            val cropY = (original.height - minSide) / 2
            val square = Bitmap.createBitmap(original, cropX, cropY, minSide, minSide)

            // Scale to 256x256
            val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)

            // Compress to WebP (or JPEG if WebP is unsupported)
            val outputFile = File(context.filesDir, "avatar.webp")
            FileOutputStream(outputFile).use { out ->
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    scaled.compress(Bitmap.CompressFormat.WEBP_LOSSY, 85, out)
                } else {
                    @Suppress("DEPRECATION")
                    scaled.compress(Bitmap.CompressFormat.WEBP, 85, out)
                }
            }

            Log.i(TAG, "Avatar salvo com sucesso: ${outputFile.length() / 1024} KB")
            Result.success(outputFile.absolutePath)
        } catch (e: Exception) {
            Log.w(TAG, "Erro ao processar avatar: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun processAndSaveBanner(context: Context, sourceUri: Uri): Result<String> = withContext(Dispatchers.IO) {
        try {
            val original = loadBitmap(context, sourceUri)
                ?: return@withContext Result.failure(IllegalStateException("Não foi possível carregar imagem da capa."))

            // Crop 16:9
            val targetRatio = 16f / 9f
            val currentRatio = original.width.toFloat() / original.height.toFloat()

            val cropWidth: Int
            val cropHeight: Int
            val cropX: Int
            val cropY: Int

            if (currentRatio > targetRatio) {
                // Wider than 16:9 -> crop width
                cropHeight = original.height
                cropWidth = (cropHeight * targetRatio).toInt()
                cropX = (original.width - cropWidth) / 2
                cropY = 0
            } else {
                // Taller than 16:9 -> crop height
                cropWidth = original.width
                cropHeight = (cropWidth / targetRatio).toInt()
                cropX = 0
                cropY = (original.height - cropHeight) / 2
            }

            val cropped = Bitmap.createBitmap(original, cropX, cropY, cropWidth, cropHeight)

            // Scale to 1280x720
            val scaled = Bitmap.createScaledBitmap(cropped, 1280, 720, true)

            // Compress to JPEG 80%
            val outputFile = File(context.filesDir, "banner.jpg")
            FileOutputStream(outputFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }

            Log.i(TAG, "Capa salva com sucesso: ${outputFile.length() / 1024} KB")
            Result.success(outputFile.absolutePath)
        } catch (e: Exception) {
            Log.w(TAG, "Erro ao processar capa: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun saveBitmapAsBanner(context: Context, bitmap: Bitmap): Result<String> = withContext(Dispatchers.IO) {
        try {
            val targetRatio = 16f / 9f
            val currentRatio = bitmap.width.toFloat() / bitmap.height.toFloat()

            val cropWidth: Int
            val cropHeight: Int
            val cropX: Int
            val cropY: Int

            if (currentRatio > targetRatio) {
                cropHeight = bitmap.height
                cropWidth = (cropHeight * targetRatio).toInt()
                cropX = (bitmap.width - cropWidth) / 2
                cropY = 0
            } else {
                cropWidth = bitmap.width
                cropHeight = (cropWidth / targetRatio).toInt()
                cropX = 0
                cropY = (bitmap.height - cropHeight) / 2
            }

            val cropped = Bitmap.createBitmap(bitmap, cropX, cropY, cropWidth, cropHeight)
            val scaled = Bitmap.createScaledBitmap(cropped, 1280, 720, true)

            val outputFile = File(context.filesDir, "banner.jpg")
            FileOutputStream(outputFile).use { out ->
                scaled.compress(Bitmap.CompressFormat.JPEG, 80, out)
            }
            Result.success(outputFile.absolutePath)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun loadBitmap(context: Context, uri: Uri): Bitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val source = ImageDecoder.createSource(context.contentResolver, uri)
                ImageDecoder.decodeBitmap(source) { decoder, _, _ ->
                    decoder.isMutableRequired = true
                }
            } else {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    BitmapFactory.decodeStream(stream)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Falha ao decodificar bitmap do Uri: ${e.message}")
            null
        }
    }
}
